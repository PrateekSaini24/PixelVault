"""
PixelVault — Flask dashboard
=============================
Serves the module dashboard and the Module 1 (Visual Cryptography) tool.
Modules 2-5 are shown as upcoming on the dashboard and get built next.
"""

import io
import os
import shutil
import tempfile
import uuid
import zipfile

from flask import (
    Flask, render_template, request, send_file, redirect, url_for, flash
)
from werkzeug.utils import secure_filename

from visual_crypto import encode_n_n, decode_n_n
from watermark import (
    embed as wm_embed, extract as wm_extract, run_robustness_suite, apply_attack,
    describe_extraction,
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
WORK_DIR = os.path.join(BASE_DIR, "tmp")
os.makedirs(WORK_DIR, exist_ok=True)

app = Flask(__name__)
app.secret_key = "pixelvault-dev-secret"  # replace before any real deployment
app.config["MAX_CONTENT_LENGTH"] = 32 * 1024 * 1024  # 32 MB upload cap

MODULES = [
    {
        "id": "module1",
        "number": 1,
        "name": "Visual Cryptography",
        "tagline": "Split a secret image into noise-shares; stack them to reveal it.",
        "status": "ready",
    },
    {
        "id": "module2",
        "number": 2,
        "name": "Robust Watermarking",
        "tagline": "Embed a traceable, invisible mark to catch leaks at the source.",
        "status": "ready",
    },
    {
        "id": "module3",
        "number": 3,
        "name": "Secure Transmission",
        "tagline": "AES-256 + RSA in transit, SHA-256 to catch tampering.",
        "status": "coming_soon",
    },
    {
        "id": "module4",
        "number": 4,
        "name": "Panic Password Vault",
        "tagline": "One password opens the real image, another opens a decoy.",
        "status": "coming_soon",
    },
    {
        "id": "module5",
        "number": 5,
        "name": "Self-Destructing Vault",
        "tagline": "Views run out, the key is shredded, the image is gone for good.",
        "status": "coming_soon",
    },
]


def _new_workdir() -> str:
    d = os.path.join(WORK_DIR, uuid.uuid4().hex)
    os.makedirs(d, exist_ok=True)
    return d


@app.route("/")
def dashboard():
    return render_template("index.html", modules=MODULES)


@app.route("/module1", methods=["GET"])
def module1():
    return render_template("module1.html")


SHARE_COUNT = 5  # fixed: this build only offers the 5-share (5,5) scheme


@app.route("/module1/split", methods=["POST"])
def module1_split():
    file = request.files.get("secret_image")
    photo_mode = bool(request.form.get("photo_mode"))

    if not file or file.filename == "":
        flash("Please choose an image to split.")
        return redirect(url_for("module1"))

    workdir = _new_workdir()
    try:
        secret_path = os.path.join(workdir, secure_filename(file.filename))
        file.save(secret_path)

        share_paths = [os.path.join(workdir, f"share_{i+1}.png") for i in range(SHARE_COUNT)]
        encode_n_n(secret_path, share_paths, sharp=not photo_mode)

        # Zip the shares for a single download.
        mem_zip = io.BytesIO()
        with zipfile.ZipFile(mem_zip, "w", zipfile.ZIP_DEFLATED) as zf:
            for p in share_paths:
                zf.write(p, arcname=os.path.basename(p))
        mem_zip.seek(0)
        return send_file(
            mem_zip,
            mimetype="application/zip",
            as_attachment=True,
            download_name="pixelvault_shares.zip",
        )
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


@app.route("/module1/combine", methods=["POST"])
def module1_combine():
    files = [f for f in request.files.getlist("shares") if f.filename]

    if len(files) != SHARE_COUNT:
        flash(f"Please choose all {SHARE_COUNT} share images to combine.")
        return redirect(url_for("module1"))

    workdir = _new_workdir()
    try:
        share_paths = []
        for f in files:
            p = os.path.join(workdir, secure_filename(f.filename))
            f.save(p)
            share_paths.append(p)

        output_path = os.path.join(workdir, "reconstructed.png")
        decode_n_n(share_paths, output_path)

        return send_file(
            output_path,
            mimetype="image/png",
            as_attachment=True,
            download_name="reconstructed.png",
        )
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


WM_ALPHA = 0.6
WM_SIZE = 16


@app.route("/module2", methods=["GET"])
def module2():
    return render_template("module2.html")


@app.route("/module2/embed", methods=["POST"])
def module2_embed():
    file = request.files.get("cover_image")
    identifier = (request.form.get("identifier") or "").strip()

    if not file or file.filename == "":
        flash("Please choose an image to watermark.")
        return redirect(url_for("module2"))
    if not identifier:
        flash("Please enter an identifier to embed (e.g. a username or ID).")
        return redirect(url_for("module2"))

    workdir = _new_workdir()
    try:
        cover_path = os.path.join(workdir, secure_filename(file.filename))
        file.save(cover_path)

        wm_path = os.path.join(workdir, "watermarked.png")
        key_path = os.path.join(workdir, "watermark_key.npz")
        try:
            wm_embed(cover_path, identifier, wm_path, key_path, alpha=WM_ALPHA, wm_size=WM_SIZE)
        except ValueError as e:
            flash(str(e))
            return redirect(url_for("module2"))

        mem_zip = io.BytesIO()
        with zipfile.ZipFile(mem_zip, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.write(wm_path, arcname="watermarked.png")
            zf.write(key_path, arcname="watermark_key.npz")
        mem_zip.seek(0)
        return send_file(
            mem_zip,
            mimetype="application/zip",
            as_attachment=True,
            download_name="pixelvault_watermarked.zip",
        )
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


@app.route("/module2/extract", methods=["POST"])
def module2_extract():
    image_file = request.files.get("watermarked_image")
    key_file = request.files.get("key_file")

    if not image_file or image_file.filename == "" or not key_file or key_file.filename == "":
        flash("Please choose both the watermarked image and its key file.")
        return redirect(url_for("module2"))

    workdir = _new_workdir()
    try:
        image_path = os.path.join(workdir, secure_filename(image_file.filename))
        key_path = os.path.join(workdir, secure_filename(key_file.filename))
        image_file.save(image_path)
        key_file.save(key_path)

        try:
            text, confidence, _ = wm_extract(image_path, key_path)
        except Exception:
            flash("Couldn't extract a watermark — check the image/key pair match.")
            return redirect(url_for("module2"))

        extract_result = {"text": describe_extraction(text, confidence), "confidence": round(confidence, 3)}
        return render_template("module2.html", extract_result=extract_result)
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


@app.route("/module2/robustness", methods=["POST"])
def module2_robustness():
    file = request.files.get("test_image")
    identifier = (request.form.get("test_identifier") or "pixelvault_demo").strip()

    if not file or file.filename == "":
        flash("Please choose an image to run the robustness test on.")
        return redirect(url_for("module2"))

    workdir = _new_workdir()
    try:
        cover_path = os.path.join(workdir, secure_filename(file.filename))
        file.save(cover_path)

        wm_path = os.path.join(workdir, "watermarked.png")
        key_path = os.path.join(workdir, "watermark_key.npz")
        try:
            wm_embed(cover_path, identifier, wm_path, key_path, alpha=WM_ALPHA, wm_size=WM_SIZE)
        except ValueError as e:
            flash(str(e))
            return redirect(url_for("module2"))

        results = run_robustness_suite(wm_path, key_path, identifier, workdir)
        return render_template("module2.html", robustness_results=results, robustness_identifier=identifier)
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


ATTACK_PARAM_DEFAULTS = {
    "jpeg": 50,      # quality (1-95)
    "resize": 0.5,   # scale factor, then resized back
    "noise": 8,       # gaussian sigma
    "blur": 1.0,      # gaussian blur radius
    "crop": 10,       # pixels shaved off each edge, then rescaled back
}


@app.route("/module2/try_attack", methods=["POST"])
def module2_try_attack():
    image_file = request.files.get("attack_image")
    key_file = request.files.get("attack_key_file")
    attack = request.form.get("attack_type", "jpeg")
    param_raw = request.form.get("attack_param", "").strip()

    if not image_file or image_file.filename == "" or not key_file or key_file.filename == "":
        flash("Please choose both the watermarked image and its key file.")
        return redirect(url_for("module2"))

    try:
        param = float(param_raw) if param_raw else ATTACK_PARAM_DEFAULTS.get(attack, 1.0)
    except ValueError:
        param = ATTACK_PARAM_DEFAULTS.get(attack, 1.0)

    workdir = _new_workdir()
    try:
        image_path = os.path.join(workdir, secure_filename(image_file.filename))
        key_path = os.path.join(workdir, secure_filename(key_file.filename))
        image_file.save(image_path)
        key_file.save(key_path)

        attacked_path = os.path.join(workdir, "attacked.png")
        try:
            apply_attack(attack, image_path, attacked_path, param)
            text, confidence, _ = wm_extract(attacked_path, key_path)
        except Exception as e:
            flash(f"Couldn't apply that attack: {e}")
            return redirect(url_for("module2"))

        result_txt = (
            f"Attack: {attack} (param={param})\n"
            f"Extracted identifier: {describe_extraction(text, confidence)}\n"
            f"Confidence: {round(confidence, 3)}\n"
        )
        mem_zip = io.BytesIO()
        with zipfile.ZipFile(mem_zip, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.write(attacked_path, arcname="attacked_image.png")
            zf.writestr("result.txt", result_txt)
        mem_zip.seek(0)
        return send_file(
            mem_zip,
            mimetype="application/zip",
            as_attachment=True,
            download_name="pixelvault_attack_test.zip",
        )
    finally:
        shutil.rmtree(workdir, ignore_errors=True)



@app.route("/<module_id>")
def module_placeholder(module_id):
    mod = next((m for m in MODULES if m["id"] == module_id), None)
    if not mod or mod["status"] == "ready":
        return redirect(url_for("dashboard"))
    return render_template("coming_soon.html", module=mod)


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
