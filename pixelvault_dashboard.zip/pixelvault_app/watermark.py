"""
PixelVault - Module 2: Robust Watermarking (DWT-DCT-SVD hybrid)
==================================================================

Embeds a small, invisible identifier (a user ID, timestamp, or any short
string) into an image, so a leaked copy can later be traced back to
whoever it was issued to.

Pipeline (matches the design doc's hybrid scheme):
  DWT  -> a 2-level Haar wavelet decomposition splits the image into
          frequency sub-bands.
  DCT  -> concentrates a sub-band's energy into fewer coefficients,
          making the embedding more resistant to JPEG-style compression.
  SVD  -> the watermark is embedded by nudging the sub-band's singular
          values, which resists geometric attacks better than embedding
          pixels or frequency coefficients directly.

The mark is written TWICE, into two different sub-bands, because no
single band survives every kind of attack well:
  - the level-2 LH ("mid-frequency") band survives JPEG compression and
    random noise well.
  - the level-2 LL ("low-frequency") band survives resizing well, since
    resizing is itself a low-pass operation that erases high-frequency
    detail wholesale.
Extraction reads both copies and returns whichever comes back cleaner --
one simple `alpha` knob controls the overall strength; the two bands
split it internally at a fixed, tuned ratio.

This is a NON-BLIND scheme: extraction needs the "key" produced at embed
time (the cover image's own singular values/vectors and the watermark's
SVD factors) -- the "stored key/singular-value reference" the design doc
describes as the non-blind alternative to needing the original image.

No external DWT library is available in this environment, so the 2D
Haar wavelet transform is implemented directly with numpy.
"""

from __future__ import annotations

import io
import os

import numpy as np
from PIL import Image
from scipy.fftpack import dct, idct

# ---------------------------------------------------------------------------
# Haar DWT (single level, 2D), implemented manually.
# ---------------------------------------------------------------------------

def _haar_1d_forward(a: np.ndarray, axis: int):
    even = np.take(a, range(0, a.shape[axis], 2), axis=axis)
    odd = np.take(a, range(1, a.shape[axis], 2), axis=axis)
    return (even + odd) / np.sqrt(2), (even - odd) / np.sqrt(2)


def _haar_1d_inverse(approx: np.ndarray, detail: np.ndarray, axis: int):
    even = (approx + detail) / np.sqrt(2)
    odd = (approx - detail) / np.sqrt(2)
    shape = list(approx.shape)
    shape[axis] *= 2
    out = np.empty(shape, dtype=approx.dtype)
    idx_even = [slice(None)] * len(shape)
    idx_odd = [slice(None)] * len(shape)
    idx_even[axis] = slice(0, None, 2)
    idx_odd[axis] = slice(1, None, 2)
    out[tuple(idx_even)] = even
    out[tuple(idx_odd)] = odd
    return out


def dwt2_haar(img: np.ndarray):
    """Single-level 2D Haar DWT. img must have even height and width.
    Returns (LL, LH, HL, HH).
    """
    low, high = _haar_1d_forward(img, axis=1)
    ll, hl = _haar_1d_forward(low, axis=0)
    lh, hh = _haar_1d_forward(high, axis=0)
    return ll, lh, hl, hh


def idwt2_haar(ll: np.ndarray, lh: np.ndarray, hl: np.ndarray, hh: np.ndarray):
    low = _haar_1d_inverse(ll, hl, axis=0)
    high = _haar_1d_inverse(lh, hh, axis=0)
    return _haar_1d_inverse(low, high, axis=1)


def _dct2(a: np.ndarray) -> np.ndarray:
    return dct(dct(a.T, norm="ortho").T, norm="ortho")


def _idct2(a: np.ndarray) -> np.ndarray:
    return idct(idct(a.T, norm="ortho").T, norm="ortho")


def _pad_to_even(y: np.ndarray):
    h, w = y.shape
    ph, pw = h + (h % 2), w + (w % 2)
    if (ph, pw) == (h, w):
        return y, (h, w)
    padded = np.zeros((ph, pw), dtype=y.dtype)
    padded[:h, :w] = y
    return padded, (h, w)


# ---------------------------------------------------------------------------
# Identifier <-> small bit-image ("logo") conversion. The first 2 bytes
# store the identifier's length so extraction knows where real data ends
# and zero-padding begins.
# ---------------------------------------------------------------------------

def identifier_to_bit_image(identifier: str, size: int) -> np.ndarray:
    max_bytes = (size * size) // 8
    payload = identifier.encode("utf-8")
    if len(payload) > max_bytes - 2:
        raise ValueError(
            f"Identifier too long: max {max_bytes - 2} bytes for a {size}x{size} watermark."
        )
    data = len(payload).to_bytes(2, "big") + payload
    data = data + b"\x00" * (max_bytes - len(data))
    bits = np.unpackbits(np.frombuffer(data, dtype=np.uint8))
    return bits.reshape(size, size).astype(np.float64) * 255.0


def bit_image_to_identifier(img: np.ndarray) -> str:
    bits = (img > 127).astype(np.uint8).flatten()
    byte_arr = np.packbits(bits[: (len(bits) // 8) * 8])
    if len(byte_arr) < 2:
        return ""
    length = max(0, min(int.from_bytes(byte_arr[:2].tobytes(), "big"), len(byte_arr) - 2))
    return byte_arr[2:2 + length].tobytes().decode("utf-8", errors="replace")


def _confidence(wm_reconstructed: np.ndarray) -> float:
    """0-1 score: how cleanly the recovered bits separate towards 0/255
    rather than sitting at a fuzzy mid-grey -- a simple robustness proxy.
    """
    normalized = wm_reconstructed / 255.0
    return float(np.clip(np.abs(normalized - 0.5).mean() * 2, 0.0, 1.0))


def is_plausible_identifier(text: str) -> bool:
    """Best-effort check that a decoded identifier looks like real text
    rather than noise: non-empty and made entirely of printable ASCII.
    A degraded image typically recovers to noise bytes, not clean text --
    this is what lets the UI show a clear message instead of symbol soup.
    """
    return bool(text) and all(32 <= ord(c) < 127 for c in text)


def describe_extraction(text: str, confidence: float) -> str:
    """A clean, user-facing string for a decoded identifier: the text
    itself if it looks plausible, otherwise a plain explanation instead
    of raw garbled bytes.
    """
    if is_plausible_identifier(text):
        return text
    return "(unreadable — the image was likely altered too much for the mark to survive)"


# ---------------------------------------------------------------------------
# Colour handling
# ---------------------------------------------------------------------------

def _load_y_channel(image_path: str):
    img = Image.open(image_path)
    if img.mode != "L":
        ycbcr = img.convert("YCbCr")
        y, cb, cr = ycbcr.split()
        return np.array(y, dtype=np.float64), cb, cr, "RGB"
    return np.array(img.convert("L"), dtype=np.float64), None, None, "L"


# ---------------------------------------------------------------------------
# Embedding / extraction -- one mark written into two sub-bands.
#   "lh": level-2 LH band, strength = alpha            (JPEG / noise)
#   "ll": level-2 LL band, strength = alpha * LL_RATIO  (resize / crop)
# ---------------------------------------------------------------------------

LL_RATIO = 0.065  # LL band is far more visually sensitive; scale its share down


def _decompose(y_padded):
    ll1, lh1, hl1, hh1 = dwt2_haar(y_padded)
    ll1_padded, ll1_shape = _pad_to_even(ll1)
    ll2, lh2, hl2, hh2 = dwt2_haar(ll1_padded)
    return (ll1, lh1, hl1, hh1), (ll1_padded, ll1_shape), (ll2, lh2, hl2, hh2)


def _mark_band(band, sw_norm, alpha):
    d = _dct2(band)
    u, s, vt = np.linalg.svd(d, full_matrices=False)
    l = min(len(s), len(sw_norm))
    s_marked = s.copy()
    s_marked[:l] = s[:l] * (1 + alpha * sw_norm[:l])
    d_marked = (u[:, :len(s_marked)] * s_marked) @ vt[:len(s_marked), :]
    return _idct2(d_marked), u, s, vt, l


def embed(cover_path: str, identifier: str, output_path: str, key_path: str,
          alpha: float = 0.6, wm_size: int = 16) -> None:
    y, cb, cr, mode = _load_y_channel(cover_path)
    y_padded, orig_shape = _pad_to_even(y)

    if min(y_padded.shape) < wm_size * 4:
        raise ValueError(
            f"Image too small for a {wm_size}x{wm_size} watermark -- use a larger image."
        )

    (ll1, lh1, hl1, hh1), (ll1_padded, ll1_shape), (ll2, lh2, hl2, hh2) = _decompose(y_padded)

    # A near-flat / very low-detail image (solid colour, blank canvas) has
    # almost no energy in its detail sub-band -- there's essentially no
    # "texture" for an SVD-based mark to ride on, and forcing one in would
    # either be visible or unreliable. Better to say so than to silently
    # produce a watermark that won't extract cleanly.
    probe_s = np.linalg.svd(_dct2(lh2), compute_uv=False)
    if probe_s[:wm_size].max() < 1e-6:
        raise ValueError(
            "This image has too little visual detail/texture for a reliable "
            "watermark (e.g. a solid colour or near-blank image). Try an "
            "image with more visual content."
        )

    wm_img = identifier_to_bit_image(identifier, wm_size)
    uw, sw, vtw = np.linalg.svd(wm_img, full_matrices=False)
    sw_max = float(sw.max()) if sw.max() > 0 else 1.0
    sw_norm = sw / sw_max

    lh2_marked, u_lh, s_lh, vt_lh, l_lh = _mark_band(lh2, sw_norm, alpha)
    ll2_marked, u_ll, s_ll, vt_ll, l_ll = _mark_band(ll2, sw_norm, alpha * LL_RATIO)

    ll1_marked_padded = idwt2_haar(ll2_marked, lh2_marked, hl2, hh2)
    ll1_marked = ll1_marked_padded[:ll1_shape[0], :ll1_shape[1]]
    y_marked_padded = idwt2_haar(ll1_marked, lh1, hl1, hh1)
    y_marked = np.clip(y_marked_padded[:orig_shape[0], :orig_shape[1]], 0, 255).astype(np.uint8)

    if mode == "RGB":
        out_img = Image.merge("YCbCr", (Image.fromarray(y_marked), cb, cr)).convert("RGB")
    else:
        out_img = Image.fromarray(y_marked, mode="L")
    out_img.save(output_path)

    np.savez(
        key_path,
        u_lh=u_lh, s_lh=s_lh, vt_lh=vt_lh, l_lh=l_lh,
        u_ll=u_ll, s_ll=s_ll, vt_ll=vt_ll, l_ll=l_ll,
        uw=uw, vtw=vtw, sw_max=sw_max,
        alpha=alpha, wm_size=wm_size,
        orig_h=orig_shape[0], orig_w=orig_shape[1],
        ll1_h=ll1_shape[0], ll1_w=ll1_shape[1],
    )


def _read_band(key, prefix, band, wm_size, sw_max):
    u, s, vt, l = key[f"u_{prefix}"], key[f"s_{prefix}"], key[f"vt_{prefix}"], int(key[f"l_{prefix}"])
    alpha = float(key["alpha"]) * (LL_RATIO if prefix == "ll" else 1.0)
    d = _dct2(band)
    s_est = np.diag(u[:, :len(s)].T @ d @ vt[:len(s), :].T)
    with np.errstate(divide="ignore", invalid="ignore"):
        sw_norm_est = np.where(s[:l] != 0, (s_est[:l] / s[:l] - 1) / alpha, 0.0)
    sw_full = np.zeros(wm_size, dtype=np.float64)
    sw_full[:l] = sw_norm_est * sw_max
    wm_reconstructed = np.clip(key["uw"] @ np.diag(sw_full) @ key["vtw"], 0, 255)
    return bit_image_to_identifier(wm_reconstructed), _confidence(wm_reconstructed), wm_reconstructed


def extract(watermarked_path: str, key_path: str):
    """Extract the identifier from `watermarked_path` using `key_path`.

    Reads the mark from both embedded sub-bands. Prefers whichever decodes
    to plausible (printable) text; if both or neither do, falls back to
    whichever has the higher bit-separation confidence. Returns
    (identifier_text, confidence, extracted bit-image) -- confidence is
    1.0 for a perfect match and drops toward 0 as the image is degraded.
    """
    key = np.load(key_path)
    wm_size = int(key["wm_size"])
    sw_max = float(key["sw_max"])
    orig_h, orig_w = int(key["orig_h"]), int(key["orig_w"])
    ll1_h, ll1_w = int(key["ll1_h"]), int(key["ll1_w"])

    y, _, _, _ = _load_y_channel(watermarked_path)
    if y.shape != (orig_h, orig_w):
        y = np.array(Image.fromarray(y.astype(np.uint8)).resize((orig_w, orig_h)), dtype=np.float64)
    y_padded, _ = _pad_to_even(y)

    ll1a, _, _, _ = dwt2_haar(y_padded)
    ll1a = ll1a[:ll1_h, :ll1_w]
    ll1a_padded, _ = _pad_to_even(ll1a)
    ll2a, lh2a, _, _ = dwt2_haar(ll1a_padded)

    candidates = [
        _read_band(key, "lh", lh2a, wm_size, sw_max),
        _read_band(key, "ll", ll2a, wm_size, sw_max),
    ]
    candidates.sort(key=lambda c: (is_plausible_identifier(c[0]), c[1]), reverse=True)
    text, confidence, wm_bits = candidates[0]
    return text, confidence, (wm_bits > 127).astype(np.uint8) * 255


# ---------------------------------------------------------------------------
# Built-in robustness test suite (mirrors the design doc's robustness
# list): JPEG compression, resizing, gaussian noise, blur, and a crop.
# ---------------------------------------------------------------------------

def apply_attack(name: str, in_path: str, out_path: str, param):
    """Apply a single named attack to an image. Used both by the built-in
    suite and by the manual "try one attack yourself" tool.
    Supported names: jpeg, resize, noise, blur, crop.
    """
    from PIL import ImageFilter

    if name == "jpeg":
        buf = io.BytesIO()
        Image.open(in_path).convert("RGB").save(buf, format="JPEG", quality=int(param))
        buf.seek(0)
        Image.open(buf).convert("RGB").save(out_path)
    elif name == "resize":
        img = Image.open(in_path)
        w, h = img.size
        scale = float(param)
        img.resize((max(1, int(w * scale)), max(1, int(h * scale)))).resize((w, h)).save(out_path)
    elif name == "noise":
        arr = np.array(Image.open(in_path).convert("RGB"), dtype=np.float64)
        noisy = np.clip(arr + np.random.normal(0, float(param), arr.shape), 0, 255).astype(np.uint8)
        Image.fromarray(noisy).save(out_path)
    elif name == "blur":
        Image.open(in_path).filter(ImageFilter.GaussianBlur(float(param))).save(out_path)
    elif name == "crop":
        img = Image.open(in_path)
        w, h = img.size
        px = int(param)
        img.crop((px, px, w - px, h - px)).resize((w, h)).save(out_path)
    else:
        raise ValueError(f"Unknown attack: {name}")


def run_robustness_suite(watermarked_path: str, key_path: str, identifier: str, workdir: str):
    attacks = [
        ("JPEG quality 80", "jpeg", 80),
        ("JPEG quality 50", "jpeg", 50),
        ("JPEG quality 30", "jpeg", 30),
        ("Resize 75% -> back", "resize", 0.75),
        ("Resize 50% -> back", "resize", 0.5),
        ("Gaussian noise", "noise", 8),
        ("Gaussian blur", "blur", 1.0),
        ("Crop 10px -> rescale", "crop", 10),
    ]
    results = []
    for i, (label, name, param) in enumerate(attacks):
        out_path = os.path.join(workdir, f"attack_{i}.png")
        try:
            apply_attack(name, watermarked_path, out_path, param)
            text, confidence, _ = extract(out_path, key_path)
            match = identifier in text
        except Exception:
            text, confidence, match = "", 0.0, False
        results.append({
            "attack": label,
            "match": match,
            "text": describe_extraction(text, confidence),
            "confidence": round(confidence, 3),
        })
    return results
