# PixelVault Dashboard

A Flask dashboard for the PixelVault image-security suite. Shows all 5
stages of the suite; click a stage to run it.

**Built so far:** Module 1 (Visual Cryptography), Module 2 (Robust
Watermarking). Modules 3-5 show as planned.

## Run it

```bash
pip install -r requirements.txt
python app.py
```

Then open http://localhost:5000 in your browser.

## What's in here

```
app.py               Flask routes for the dashboard + both modules
visual_crypto.py      Module 1: (n,n) visual-crypto encode/decode logic
watermark.py           Module 2: DWT-DCT-SVD watermark embed/extract
templates/
  base.html            Shared layout
  index.html           Dashboard (pipeline of all 5 modules)
  module1.html          Visual crypto split/combine tool page
  module2.html          Watermark embed/extract/robustness-test tool page
  coming_soon.html      Placeholder for modules 3-5
static/style.css        Styling
uploads/, tmp/           Scratch folders used during processing (auto-cleaned)
```

## Module 1 — Visual Cryptography

- **Split** — upload any image, get 5 noise-like shares back in a `.zip`.
  All 5 are required to reconstruct.
- **Combine** — upload all 5 shares, get the reconstructed image back,
  pixel-perfect (no visual noise) by default. There's a "Photo mode"
  checkbox for photos/gradients, which halftones instead of using a plain
  threshold — off by default so text, diagrams and screenshots stay crisp.

## Module 2 — Robust Watermarking

- **Embed** — upload an image + a short identifier (username, ID,
  timestamp — up to ~14 characters). Get back the watermarked image and a
  **key file** (`.npz`). Keep the key file — this is a non-blind scheme,
  so the key is required to ever extract the mark again.
- **Extract** — upload a watermarked image + its key file, get the
  identifier back plus a confidence score.
- **Test robustness** — embeds a test identifier and runs it through
  JPEG compression, resizing, noise, blur and cropping, showing which
  attacks the mark survives. The mark is written into two different
  sub-bands internally (one tuned for JPEG/noise, one for resizing), and
  extraction automatically uses whichever comes back cleaner. Typical
  results: survives JPEG compression (quality 30-95) and moderate noise
  reliably; heavy resizing, blurring, or cropping can still break it,
  since those need extra geometric-synchronization work beyond this
  build's scope.
- **Try an attack yourself** — pick a specific attack (JPEG/resize/
  noise/blur/crop) and strength, apply it to a watermarked image, and get
  back the attacked image plus the extraction result in a `.zip`, so you
  can inspect any case yourself instead of only trusting the automatic
  suite. The input image doesn't need to be a JPEG — any format works,
  the tool creates the degraded version internally.

## Adding modules 3-5

Each future module gets its own `moduleN.html` + routes in `app.py`, and
its `MODULES` entry in `app.py` flipped to `"status": "ready"` — the
dashboard link activates automatically.

## Note on `app.secret_key`

`app.py` uses a hardcoded dev secret key for flash messages. Replace it
with an environment-variable-based secret before deploying this anywhere
beyond your own machine.
