"""
PixelVault - Module 1: Visual Cryptography for Secure Key/Image Sharing
=========================================================================

Implements Naor-Shamir-style visual secret sharing:

  - encode_2_2 / decode_2_2   : (2,2) threshold scheme (both shares needed)
  - encode_n_n / decode_n_n   : (n,n) threshold scheme (all n shares needed)

Each secret pixel is expanded into a small sub-pixel block in every share.
Shares individually look like random noise; stacking (logical OR) the
required shares reconstructs the secret.

Grayscale / colour images are supported via halftoning (dithering) into a
binary approximation before splitting, as described in the design doc's
"Colour Visual Cryptography" extension.

Decoding does two things:
  1. Stacks the shares (the actual "no computation needed" visual step —
     this alone is enough to make out the secret with the naked eye, at
     reduced contrast, exactly like real overlaid transparencies).
  2. Cleans that stack up into a pixel-perfect black/white image. Since we
     control the exact sub-pixel construction, we know precisely which
     stacked block-density corresponds to "black" vs "white" in the
     original — so this step is an exact digital touch-up, not a guess,
     and removes the grey speckle a plain optical overlay would still show.
"""

from __future__ import annotations

import itertools
import random
from pathlib import Path

import numpy as np
from PIL import Image

# ---------------------------------------------------------------------------
# (2,2) scheme: classic 2x2 sub-pixel patterns.
# WHITE secret pixel -> both shares get the SAME pattern (stacked density 1/4).
# BLACK secret pixel -> shares get COMPLEMENTARY patterns (stacked density 4/4).
# ---------------------------------------------------------------------------
_BASE_PATTERNS = [
    np.array([[1, 0], [0, 0]], dtype=np.uint8),
    np.array([[0, 1], [0, 0]], dtype=np.uint8),
    np.array([[0, 0], [1, 0]], dtype=np.uint8),
    np.array([[0, 0], [0, 1]], dtype=np.uint8),
]


def _to_binary_array(image_path: str, sharp: bool = True) -> np.ndarray:
    """Load an image and reduce it to a binary (0/1) array.

    sharp=True  -> plain threshold, no error-diffusion. Correct choice for
                   diagrams, screenshots, text, QR codes, logos: edges stay
                   crisp instead of picking up a dithering zigzag.
    sharp=False -> Floyd-Steinberg halftone dithering. Better for photos and
                   gradients, which have no hard edges to begin with, at the
                   cost of a grainy look on any edge that *is* present
                   (matches the design doc's "Colour Visual Cryptography"
                   halftone extension).
    """
    img = Image.open(image_path).convert("L")
    if sharp:
        bw = img.convert("1", dither=Image.NONE)
    else:
        bw = img.convert("1", dither=Image.FLOYDSTEINBERG)
    # PIL mode "1" arrays are boolean: True = white, False = black.
    arr = np.array(bw, dtype=bool)
    return (~arr).astype(np.uint8)  # 1 = black(secret), 0 = white


def _pattern_pair_for_pixel(is_black: bool, rng: random.Random):
    base = rng.choice(_BASE_PATTERNS)
    if is_black:
        return base, 1 - base
    return base, base


def encode_2_2(image_path: str, share1_path: str, share2_path: str,
               seed: int | None = None, sharp: bool = True) -> tuple[int, int]:
    """Split `image_path` into two shares using the (2,2) scheme."""
    rng = random.Random(seed)
    secret = _to_binary_array(image_path, sharp=sharp)
    h, w = secret.shape

    share1 = np.zeros((h * 2, w * 2), dtype=np.uint8)
    share2 = np.zeros((h * 2, w * 2), dtype=np.uint8)

    for y in range(h):
        for x in range(w):
            pat_a, pat_b = _pattern_pair_for_pixel(bool(secret[y, x]), rng)
            share1[y * 2:y * 2 + 2, x * 2:x * 2 + 2] = pat_a
            share2[y * 2:y * 2 + 2, x * 2:x * 2 + 2] = pat_b

    _save_binary_array(share1, share1_path)
    _save_binary_array(share2, share2_path)
    return w, h


def decode_2_2(share1_path: str, share2_path: str, output_path: str) -> None:
    """Reconstruct the secret from two shares: stack, then clean up.

    By construction, a black secret pixel always stacks to a fully-black
    2x2 block (density 4/4) and a white one always stacks to exactly one
    black sub-pixel (density 1/4) -- so thresholding "is the block fully
    black?" recovers the original pixel exactly, with no speckle.
    """
    s1 = _load_binary_array(share1_path)
    s2 = _load_binary_array(share2_path)
    if s1.shape != s2.shape:
        raise ValueError("Shares must be the same size to stack.")
    stacked = np.bitwise_or(s1, s2)
    clean = _clean_from_stack(stacked, block_h=2, block_w=2)
    _save_binary_array(clean, output_path)


# ---------------------------------------------------------------------------
# (n,n) scheme, n >= 3: general basis-matrix construction.
#
# For each secret pixel, take all length-n bit vectors of a fixed parity:
#   - BLACK pixel -> all ODD-weight vectors  (m = 2^(n-1) of them)
#   - WHITE pixel -> all EVEN-weight vectors (m = 2^(n-1) of them, this set
#                    always includes the all-zero vector)
# Shuffle their order per pixel, then share i's sub-pixel row is bit i of
# every vector. Stacking (OR) all n shares for one pixel ORs together every
# one of those m columns:
#   - every odd-weight vector is non-zero -> a BLACK pixel's block always
#     stacks to full density (m/m black).
#   - the even-weight set contains exactly one all-zero vector -> a WHITE
#     pixel's block always stacks to (m-1)/m black -- never fully black.
# So "is every sub-pixel black?" is an exact (not approximate) test,
# regardless of how many shares n there are. This is also the property
# that keeps the scheme safe: any n-1 shares are statistically identical
# whether the pixel was black or white.
#
# Sub-pixels are laid out as a (2 x m/2) block per share.
# ---------------------------------------------------------------------------

def _basis_columns(n: int, parity: int) -> list[tuple[int, ...]]:
    return [v for v in itertools.product((0, 1), repeat=n) if sum(v) % 2 == parity]


def encode_n_n(image_path: str, share_paths: list[str],
               seed: int | None = None, sharp: bool = True) -> tuple[int, int]:
    """Split an image into n shares, ALL of which are required to
    reconstruct it (an (n,n) threshold scheme).
    """
    n = len(share_paths)
    if n < 2:
        raise ValueError("n-out-of-n scheme requires at least 2 shares.")

    rng = random.Random(seed)
    secret = _to_binary_array(image_path, sharp=sharp)
    h, w = secret.shape

    m = 2 ** (n - 1)
    block_h, block_w = 2, m // 2

    black_cols = _basis_columns(n, 1)
    white_cols = _basis_columns(n, 0)

    shares = [np.zeros((h * block_h, w * block_w), dtype=np.uint8) for _ in range(n)]

    for y in range(h):
        for x in range(w):
            cols = list(black_cols if secret[y, x] else white_cols)
            rng.shuffle(cols)
            for i in range(n):
                bits = np.array([cols[j][i] for j in range(m)], dtype=np.uint8)
                block = bits.reshape(block_h, block_w)
                shares[i][y * block_h:(y + 1) * block_h,
                          x * block_w:(x + 1) * block_w] = block

    for path, arr in zip(share_paths, shares):
        _save_binary_array(arr, path)
    return w, h


def decode_n_n(share_paths: list[str], output_path: str) -> None:
    """Reconstruct the secret by stacking all n shares, then cleaning up
    the result using the exact density test described above.
    """
    n = len(share_paths)
    arrays = [_load_binary_array(p) for p in share_paths]
    shape = arrays[0].shape
    if any(a.shape != shape for a in arrays):
        raise ValueError("All shares must be the same size to stack.")
    stacked = arrays[0]
    for a in arrays[1:]:
        stacked = np.bitwise_or(stacked, a)

    m = 2 ** (n - 1)
    block_h, block_w = 2, m // 2
    clean = _clean_from_stack(stacked, block_h, block_w)
    _save_binary_array(clean, output_path)


def _clean_from_stack(stacked: np.ndarray, block_h: int, block_w: int) -> np.ndarray:
    """Digitally clean a raw visual-OR stack into a pixel-perfect binary
    image: a secret pixel was black iff its whole sub-pixel block is
    fully black once every required share is stacked.
    """
    H2, W2 = stacked.shape
    h, w = H2 // block_h, W2 // block_w
    m = block_h * block_w
    reshaped = stacked.reshape(h, block_h, w, block_w)
    block_sums = reshaped.sum(axis=(1, 3))
    return (block_sums == m).astype(np.uint8)


# ---------------------------------------------------------------------------
# I/O helpers
# ---------------------------------------------------------------------------

def _save_binary_array(arr: np.ndarray, path: str) -> None:
    """Save a 0/1 array as a black/white PNG (1 = black, 0 = white)."""
    img = Image.fromarray(np.where(arr == 1, 0, 255).astype(np.uint8), mode="L")
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    img.save(path)


def _load_binary_array(path: str) -> np.ndarray:
    img = Image.open(path).convert("L")
    arr = np.array(img, dtype=np.uint8)
    return (arr < 128).astype(np.uint8)
